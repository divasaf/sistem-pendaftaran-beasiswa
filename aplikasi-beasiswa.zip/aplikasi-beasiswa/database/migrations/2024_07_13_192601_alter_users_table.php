<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->renameColumn('name', 'nama');
            $table->dropColumn('email');
            $table->string('nik')->unique()->after('nama');
            $table->string('username')->unique()->after('nik');
            $table->text('alamat')->after('username');
            $table->string('no_hp')->unique()->after('alamat');
            $table->integer('status')->nullable()->after('no_hp');
            $table->enum('role', ['peserta', 'petugas'])->comment('peserta, petugas')->after('status');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            $table->renameColumn('nama', 'name');
            $table->string('email')->unique();
            $table->dropColumn('nik');
            $table->dropColumn('username');
            $table->dropColumn('alamat');
            $table->dropColumn('no_hp');
            $table->dropColumn('status');
            $table->dropColumn('role');
        });
    }
};
