<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link href="{{asset('assets_wb/vendor/fontawesome-free/css/all.min.css')}}" rel="stylesheet" type="text/css">
    <link href="{{asset('assets_wb/css/sb-admin-2.min.css')}}" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <!-- my css -->
    <link rel="stylesheet" href="{{asset('assets_wb/css/style.css')}}">
    <style>
        html, body {
            height: 100%;
        }
        .card-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
    </style>
</head>
<body>
    <div class="container card-container">
        <div class="card shadow-sm" style="width: 100%; max-width: 600px;">
            <div class="card-body">
                <h3 class="card-title text-center mb-4">Register Peserta</h3>
                <form action="{{ route('auth.register.post') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="text" name="nik" id="nik" class="form-control" value="{{ old('nik', rand(1111111111111111, 9999999999999999)) }}">
                        @if ($errors->has('nik'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('nik') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="{{ old('nama' ?? '') }}">
                        @if ($errors->has('nama'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('nama') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" class="form-control" value="{{ old('username' ?? '') }}">
                        @if ($errors->has('username'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('username') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control" value="{{ old('alamat' ?? '') }}">
                        @if ($errors->has('alamat'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('alamat') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="no_hp">No Handphone</label>
                        <input type="text" name="no_hp" id="no_hp" class="form-control" value="{{ old('no_hp' ?? '') }}">
                        @if ($errors->has('no_hp'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('no_hp') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control" value="{{ old('password' ?? '') }}">
                        @if ($errors->has('password'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('password') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Password Confirmation</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" value="{{ old('confirm_password' ?? '') }}">
                        @if ($errors->has('confirm_password'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('confirm_password') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Register</button>
                </form>
                <br>
                <div class="row">
                    <div class="col-md-6">
                        <a href="{{ route('auth.login') }}" style="">Login?</a>
                    </div>
                    <div class="col-md-6 text-right">
                        <a href="{{ route('auth.petugas.login') }}" style="">Login Sebagai Petugas?</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
