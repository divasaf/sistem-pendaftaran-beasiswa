@extends('layout.template-admin')

@section('title')
    Admin | Pengajuan | Create
@endsection

@section('content')
    <div class="container-fluid">
        <h3>Form Create Pengajuan</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="{{ route('admin.pengajuan.store') }}" method="POST" enctype="multipart/form-data">
                    @csrf
                    <div class="form-group">
                        <label for="beasiswa_id">Beasiswa</label>
                        <select name="beasiswa_id" id="beasiswa_id" class="form-control">
                            <option value="">Pilih Beasiswa</option>
                            @foreach ($beasiswa as $b)
                                <option value="{{ $b->id ?? '' }}" {{ old('beasiswa_id') == $b->id ? 'selected' : '' }}>{{ $b->nama ?? '' }}</option>
                            @endforeach
                        </select>
                        @if ($errors->has('beasiswa_id'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('beasiswa_id') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="users_id">Peserta</label>
                        <select name="users_id" id="users_id" class="form-control">
                            <option value="">Pilih Peserta</option>
                            @foreach ($users as $u)
                                <option value="{{ $u->id ?? '' }}" {{ old('users_id') == $u->id ? 'selected' : '' }}>{{ $u->nama . ' - ' . $u->nik ?? '' }}</option>
                            @endforeach
                        </select>
                        @if ($errors->has('users_id'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('users_id') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="hasil_ujian">Hasil Ujian</label>
                        <input type="file" name="hasil_ujian" id="hasil_ujian" class="form-control" value="{{ old('hasil_ujian' ?? '') }}">
                        @if ($errors->has('hasil_ujian'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('hasil_ujian') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
@endsection