@extends('layout.template-admin')
@section('title')
    Admin | Pengajuan
@endsection

@section('content')

<div class="conttainer-md">

    <h3>Pengajuan</h3>

    <a href="{{ route('admin.pengajuan.create') }}" type="button" class="btn btn-success"> + Tambah Pengajuan</a>

    <br />
    <br />
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Beasiswa</th>
                <th>Peserta</th>
                <th>Hasil Ujian</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            @if (count($pengajuan) > 0)
                @foreach($pengajuan as $p)
                <tr>
                    <td scope="row"><?= $loop->index + 1 ?></td>
                    <td>{{ $p->beasiswa->nama ?? '' }}</td>
                    <td>{{ $p->user->nama . ' - ' . $p->user->nik ?? '' }}</td>
                    <td><a href="{{ Storage::url($p->hasil_ujian) }}" target="_blank">{{ substr($p->hasil_ujian, 8) }}</a></td>
                    <td>
                        <a href="{{ route('admin.pengajuan.edit', $p->id) }}" type="button" class="btn btn-success">Edit</a>
                        |
                        <a href="{{ route('admin.pengajuan.delete', $p->id) }}" type="button" onclick="return confirm('Yakin ingin menghapus data？')" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                @endforeach
            @else 
                <tr>
                    <td colspan="6" class="text-center"><h3>Tidak Ada Data</h3></td>
                </tr>
            @endif
        </tbody>
    </table>
</div>
@endsection