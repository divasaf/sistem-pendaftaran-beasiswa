@extends('layout.template-admin')

@section('title')
    Admin | Beasiswa | Create
@endsection

@section('content')
    <div class="container-fluid">
        <h3>Form Create Beasiswa</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="{{ route('admin.beasiswa.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="nama">Nama Beasiswa</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="{{ old('nama' ?? '') }}">
                        @if ($errors->has('nama'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('nama') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="sponsor">Sponsor</label>
                        <input type="text" name="sponsor" id="sponsor" class="form-control" value="{{ old('sponsor' ?? '') }}">
                        @if ($errors->has('sponsor'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('sponsor') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="id_jurusan">Jurusan</label>
                        <select name="id_jurusan" id="id_jurusan" class="form-control">
                            <option value="">Pilih jurusan</option>
                            @foreach ($jurusan as $j)
                                <option value="{{ $j->id ?? '' }}" {{ old('id_jurusan') == $j->id ? 'selected' : '' }}>{{ $j->nama ?? '' }}</option>
                            @endforeach
                        </select>
                        @if ($errors->has('id_jurusan'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('id_jurusan') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="id_ujian">Ujian</label>
                        <select name="id_ujian" id="id_ujian" class="form-control">
                            <option value="">Pilih ujian</option>
                            @foreach ($ujian as $u)
                                <option value="{{ $u->id ?? '' }}" {{ old('id_ujian') == $u->id ? 'selected' : '' }}>{{ $u->nama ?? '' }}</option>
                            @endforeach
                        </select>
                        @if ($errors->has('id_ujian'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('id_ujian') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
@endsection