@extends('layout.template-admin')

@section('title')
    Admin | Beasiswa
@endsection

@section('content')

<div class="conttainer-md">

    <h3>Beasiswa</h3>

    <a href="{{ route('admin.beasiswa.create') }}" type="button" class="btn btn-success"> + Tambah Beasiswa</a>

    <br />
    <br />
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Nama Beasiswa</th>
                <th>Sponsor</th>
                <th>Jurusan</th>
                <th>Ujian</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            @if (count($beasiswa) > 0)
                @foreach($beasiswa as $b)
                <tr>
                    <td scope="row"><?= $loop->index + 1 ?></td>
                    <td>{{ $b->nama }}</td>
                    <td>{{ $b->sponsor }}</td>
                    <td>{{ $b->jurusan->nama ?? '' }}</td>
                    <td>{{ $b->ujian->nama ?? '' }}</td>
                    <td>
                        <a href="{{ route('admin.beasiswa.edit', $b->id) }}" type="button" class="btn btn-success">Edit</a>
                        |
                        <a href="{{ route('admin.beasiswa.delete', $b->id) }}" type="button" onclick="return confirm('Yakin ingin menghapus data？')" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                @endforeach
            @else 
                <tr>
                    <td colspan="6" class="text-center"><h3>Tidak Ada Data</h3></td>
                </tr>
            @endif
        </tbody>
    </table>
</div>
@endsection