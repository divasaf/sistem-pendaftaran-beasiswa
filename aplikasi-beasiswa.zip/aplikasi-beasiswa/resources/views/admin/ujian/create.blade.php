@extends('layout.template-admin')

@section('title')
    Admin | Ujian | Create
@endsection

@section('content')
    <div class="container-fluid">
        <h3>Form Create Ujian</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="{{ route('admin.ujian.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="nama">Nama Ujian</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="{{ old('nama' ?? '') }}">
                        @if ($errors->has('nama'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('nama') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="link">Link</label>
                        <input type="text" name="link" id="link" class="form-control" value="{{ old('link' ?? '') }}">
                        @if ($errors->has('link'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('link') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
@endsection