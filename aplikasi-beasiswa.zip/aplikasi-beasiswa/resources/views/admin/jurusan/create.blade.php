@extends('layout.template-admin')

@section('title')
    Admin | Jurusan | Create
@endsection

@section('content')
    <div class="container-fluid">
        <h3>Form Create Jurusan</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="{{ route('admin.jurusan.store') }}" method="POST">
                    @csrf
                    <div class="form-group">
                        <label for="nama">Nama Jurusan</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="{{ old('nama' ?? '') }}">
                        @if ($errors->has('nama'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('nama') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
@endsection