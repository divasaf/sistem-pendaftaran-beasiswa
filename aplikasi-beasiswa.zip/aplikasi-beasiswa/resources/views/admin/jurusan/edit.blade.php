@extends('layout.template-admin')

@section('title')
    Admin | Jurusan | Edit
@endsection

@section('content')
    <div class="container-fluid">
        <h3>Form Edit Jurusan</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="{{ route('admin.jurusan.update', $jurusan->id) }}" method="POST">
                    @csrf
                    @method('PATCH')
                    <div class="form-group">
                        <label for="nama">Nama Jurusan</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="{{ (old('nama') == '') ? $jurusan->nama : '' }}">
                        @if ($errors->has('nama'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('nama') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-success">Update</button>
                </form>
            </div>
        </div>
    </div>
@endsection