@extends('layout.template-admin')

@section('title')
    Admin | Petugas | Create
@endsection

@section('content')
    <div class="container-fluid">
        <h3>Form Create Petugas</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="{{ route('admin.petugas.update', $petugas->id) }}" method="POST">
                    @csrf
                    @method('PATCH')
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="text" name="nik" id="nik" class="form-control" value="{{ old('nik', $petugas->nik ?? '') }}">
                        @if ($errors->has('nik'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('nik') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="{{ old('nama', $petugas->nama ?? '') }}">
                        @if ($errors->has('nama'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('nama') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" class="form-control" value="{{ old('username', $petugas->username ?? '') }}">
                        @if ($errors->has('username'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('username') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control" value="{{ old('alamat', $petugas->alamat ?? '') }}">
                        @if ($errors->has('alamat'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('alamat') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="no_hp">No Handphone</label>
                        <input type="text" name="no_hp" id="no_hp" class="form-control" value="{{ old('no_hp', $petugas->no_hp ?? '') }}">
                        @if ($errors->has('no_hp'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('no_hp') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control" value="{{ old('password' ?? '') }}">
                        @if ($errors->has('password'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('password') }}</span>
                        @endif
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Password Confirmation</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" value="{{ old('confirm_password' ?? '') }}">
                        @if ($errors->has('confirm_password'))
                            <span style="font-size: 13px; color: rgb(192, 40, 40);">{{ $errors->first('confirm_password') }}</span>
                        @endif
                    </div>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
@endsection