@extends('layout.template-admin')
@section('title')
    Admin | Petugas
@endsection

@section('content')

<div class="conttainer-md">

    <h3>Petugas</h3>

    <a href="{{ route('admin.petugas.create') }}" type="button" class="btn btn-success"> + Tambah Petugas</a>

    <br />
    <br />
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Alamat</th>
                <th>No Hp</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            @if (count($petugas) > 0)
                @foreach($petugas as $p)
                <tr>
                    <td scope="row"><?= $loop->index + 1 ?></td>
                    <td>{{ $p->nama }}</td>
                    <td>{{ $p->nik }}</td>
                    <td>{{ $p->alamat }}</td>
                    <td>{{ $p->no_hp }}</td>
                    <td>
                        <a href="{{ route('admin.petugas.edit', $p->id) }}" type="button" class="btn btn-success">Edit</a>
                        |
                        <a href="{{ route('admin.petugas.delete', $p->id) }}" type="button" onclick="return confirm('Yakin ingin menghapus data？')" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                @endforeach
            @else 
                <tr>
                    <td colspan="6" class="text-center"><h3>Tidak Ada Data</h3></td>
                </tr>
            @endif
        </tbody>
    </table>
</div>
@endsection