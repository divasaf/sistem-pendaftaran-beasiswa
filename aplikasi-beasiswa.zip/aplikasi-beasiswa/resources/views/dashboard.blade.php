@extends('layout.template-admin')

@section('content')


<h1>SELAMAT DATANG DI DASHBOARD ADMIN!</h1>



@endsection