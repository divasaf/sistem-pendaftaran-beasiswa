<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class AuthPetugasController extends Controller
{
    public function login(){
        return view('auth.petugas.login');
    }

    public function loginPost(Request $request)
    {
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ], [
            'username.required' => 'Username harus diisi.',
            'password.required' => 'Password harus diisi.',
        ]);

        $user = User::where('username', $request->username)->first();

        if (!$user || !Hash::check($request->password, $user->password)) {
            return back()->with('error', 'Username atau password salah');
        }

        if($user->role != 'petugas'){
            return back()->with('error', 'Username atau password salah');
        }

        Session::put('users_id', $user->id ?? '');
        Session::put('users_nama', $user->nama ?? '');
        Session::put('users_username', $user->username ?? '');
        Session::put('users_nik', $user->nik ?? '');
        Session::put('users_role', $user->role ?? '');
        
        return redirect()->route('admin.dashboard.index');
    }

    public function register(){
        return view('auth.petugas.register');
    }

    public function registerPost(Request $request){
        $rules = [
            'nama' => 'required|string|max:255',
            'nik' => 'required|integer|digits:16|unique:users,nik',
            'username' => 'required|string|max:255|unique:users,username',
            'alamat' => 'required|string|max:255',
            'no_hp' => 'required|string|max:16|unique:users,no_hp',
            'password' => 'min:8|required_with:confirm_password|same:confirm_password',
            'confirm_password' => 'min:8|required_with:password|same:password',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'integer' => ':attribute harus berupa angka.',
            'digits' => ':attribute harus terdiri dari :digits digit.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
            'min' => ':attribute tidak boleh kurang dari :min karakter.',
            'exists' => ':attribute yang dipilih tidak valid.',
            'unique' => ':attribute sudah terdaftar.',
            'required_with' => ':attribute harus di isi jika :values terisi',
            'same' => ':attribute tidak seusai dengan :other',
        ];
    
        $attributes = [
            'nama' => 'Nama',
            'nik' => 'NIK',
            'username' => 'Username',
            'alamat' => 'Alamat',
            'no_hp' => 'No HP',
            'password' => 'Password',
            'confirm_password' => 'Konfirmasi Password',
        ];

        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        DB::beginTransaction();
        try{
            User::create([
                'nama' => $request->nama ?? '',
                'nik' => $request->nik ?? '',
                'username' => $request->username ?? '',
                'alamat' => $request->alamat ?? '',
                'no_hp' => $request->no_hp ?? '',
                'role' => 'petugas',
                'password' => Hash::make($request->password),
            ]);
            DB::commit();
        }catch(QueryException $ex){
            DB::rollback();
            return back()->with('error', $ex->getMessage())->withInput();
        }
        return redirect()->route('auth.petugas.login')->with('success', 'Berhasil register petugas');
    }
}
