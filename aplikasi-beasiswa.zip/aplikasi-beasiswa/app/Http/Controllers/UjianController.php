<?php

namespace App\Http\Controllers;

use App\Models\Ujian;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class UjianController extends Controller
{
    public function index(){
        $ujian = Ujian::get();
        return view('admin.ujian.index', ['ujian' => $ujian]);
    }

    public function create(){
        return view('admin.ujian.create');
    }

    public function store(Request $request){
        $rules = [
            'nama' => 'required|string|max:255',
            'link' => 'required',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
        ];
    
        $attributes = [
            'nama' => 'Nama Jurusan',
            'link' => 'Link',
        ];
    
        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            $ujian = Ujian::create([
                'nama' => $request->nama,
                'link' => $request->link,
            ]);
        }catch (QueryException $ex){
            return back()->with('error', $ex->getMessage())->withInput();
        }

        return redirect()->route('admin.ujian.index')->with('success', 'Berhasil membuat ujian');
    }

    public function edit($id){
        $ujian = Ujian::where('id', $id)->first();
        return view('admin.ujian.edit', ['ujian' => $ujian]);
    }

    public function update(Request $request, $id){
        $rules = [
            'nama' => 'required|string|max:255',
            'link' => 'required',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
        ];
    
        $attributes = [
            'nama' => 'Nama Jurusan',
            'link' => 'Link',
        ];
    
        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            $ujian = Ujian::where('id', $id)->update([
                'nama' => $request->nama,
                'link' => $request->link,
            ]);
        }catch (QueryException $ex){
            return back()->with('error', $ex->getMessage())->withInput();
        }

        return redirect()->route('admin.ujian.index')->with('success', 'Berhasil mengubah ujian');
    }

    public function delete($id){
        $ujian = ujian::where('id', $id)->first();
        $ujian->delete();
        return redirect()->route('admin.ujian.index')->with('success', 'Berhasil menghapus ujian');
    }
}
