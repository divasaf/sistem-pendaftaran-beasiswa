<?php

namespace App\Http\Controllers;

use App\Models\Jurusan;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class JurusanController extends Controller
{
    public function index(){
        $jurusan = Jurusan::get();
        return view('admin.jurusan.index', ['jurusan' => $jurusan]);
    }

    public function create(){
        return view('admin.jurusan.create');
    }

    public function store(Request $request){
        $rules = [
            'nama' => 'required|string|max:255',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
        ];
    
        $attributes = [
            'nama' => 'Nama Jurusan',
        ];
    
        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            $jurusan = Jurusan::create([
                'nama' => $request->nama,
            ]);
        }catch (QueryException $ex){
            return back()->with('error', $ex->getMessage())->withInput();
        }

        return redirect()->route('admin.jurusan.index')->with('success', 'Berhasil membuat jurusan');
    }

    public function edit($id){
        $jurusan = Jurusan::where('id', $id)->first();
        return view('admin.jurusan.edit', ['jurusan' => $jurusan]);
    }

    public function update(Request $request, $id){
        $rules = [
            'nama' => 'required|string|max:255',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
        ];
    
        $attributes = [
            'nama' => 'Nama Jurusan',
        ];
    
        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        try {
            $jurusan = Jurusan::where('id', $id)->update([
                'nama' => $request->nama,
            ]);
        }catch (QueryException $ex){
            return back()->with('error', $ex->getMessage())->withInput();
        }

        return redirect()->route('admin.jurusan.index')->with('success', 'Berhasil mengubah jurusan');
    }

    public function delete($id){
        $jurusan = Jurusan::where('id', $id)->first();
        $jurusan->delete();
        return redirect()->route('admin.jurusan.index')->with('success', 'Berhasil menghapus jurusan');
    }
}
