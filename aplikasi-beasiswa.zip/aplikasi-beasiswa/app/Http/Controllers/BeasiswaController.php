<?php

namespace App\Http\Controllers;

use App\Models\Ujian;
use App\Models\Jurusan;
use App\Models\Beasiswa;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class BeasiswaController extends Controller
{
    public function index(){
        $beasiswa = Beasiswa::with(['jurusan', 'ujian'])->get();
        //dd($beasiswa);
        return view('admin.beasiswa.index', ['beasiswa' => $beasiswa]);
    }

    public function create(){
        $ujian = Ujian::select('id', 'nama')->get();
        $jurusan = Jurusan::get();

        return view('admin.beasiswa.create', ['ujian' => $ujian, 'jurusan' => $jurusan]);
    }

    public function store(Request $request){
        $rules = [
            'nama' => 'required|string|max:255',
            'sponsor' => 'required|string|max:255',
            'id_jurusan' => 'required|exists:jurusan,id',
            'id_ujian' => 'required|exists:ujian,id',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
            'exists' => ':attribute yang dipilih tidak valid.',
        ];
    
        $attributes = [
            'nama' => 'Nama Beasiswa',
            'sponsor' => 'Sponsor',
            'id_jurusan' => 'Jurusan',
            'id_ujian' => 'Ujian',
        ];
    
        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        DB::beginTransaction();
        try{
            Beasiswa::create([
                'nama' => $request->nama ?? '',
                'sponsor' => $request->sponsor ?? '',
                'id_jurusan' => $request->id_jurusan ?? '',
                'id_ujian' => $request->id_ujian ?? '',
            ]);
            DB::commit();
        }catch(QueryException $ex){
            DB::rollback();
            return back()->with('error', $ex->getMessage())->withInput();
        }
        return redirect()->route('admin.beasiswa.index')->with('success', 'Berhasil membuat beasiswa');
    }

    public function edit($id){
        $ujian = Ujian::select('id', 'nama')->get();
        $jurusan = Jurusan::get();
        $beasiswa = Beasiswa::where('id', $id)->first();

        return view('admin.beasiswa.edit', ['ujian' => $ujian, 'jurusan' => $jurusan, 'beasiswa' => $beasiswa]);
    }

    public function update(Request $request, $id){
        $rules = [
            'nama' => 'required|string|max:255',
            'sponsor' => 'required|string|max:255',
            'id_jurusan' => 'required|exists:jurusan,id',
            'id_ujian' => 'required|exists:ujian,id',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
            'exists' => ':attribute yang dipilih tidak valid.',
        ];
    
        $attributes = [
            'nama' => 'Nama Beasiswa',
            'sponsor' => 'Sponsor',
            'id_jurusan' => 'Jurusan',
            'id_ujian' => 'Ujian',
        ];
    
        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        DB::beginTransaction();
        try{
            Beasiswa::where('id', $id)->update([
                'nama' => $request->nama ?? '',
                'sponsor' => $request->sponsor ?? '',
                'id_jurusan' => $request->id_jurusan ?? '',
                'id_ujian' => $request->id_ujian ?? '',
            ]);
            DB::commit();
        }catch(QueryException $ex){
            DB::rollback();
            return back()->with('error', $ex->getMessage())->withInput();
        }
        return redirect()->route('admin.beasiswa.index')->with('success', 'Berhasil mengubah beasiswa');
    }

    public function delete($id){
        $beasiswa = Beasiswa::where('id', $id)->first();
        $beasiswa->delete();
        return redirect()->route('admin.beasiswa.index')->with('success', 'Berhasil menghapus beasiswa');
    }
}
