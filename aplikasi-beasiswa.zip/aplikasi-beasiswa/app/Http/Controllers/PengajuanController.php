<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Beasiswa;
use App\Models\Pengajuan;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Database\QueryException;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Validator;

class PengajuanController extends Controller
{
    public function index(){
        $pengajuan = Pengajuan::with(['beasiswa', 'user'])->get();
        return view('admin.pengajuan.index', ['pengajuan' => $pengajuan]);
    }

    public function create(){
        $beasiswa = Beasiswa::get();
        $users = User::where('role', 'peserta')->where('id', '!=', Session::get('user_id'))->get();
        return view('admin.pengajuan.create', ['users' => $users, 'beasiswa' => $beasiswa]);
    }

    public function store(Request $request){
        $rules = [
            'beasiswa_id' => 'required|exists:beasiswa,id',
            'users_id' => 'required|exists:users,id',
            'hasil_ujian' => 'required|file|max:2048|mimes:pdf,doc,docx',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'max' => 'Ukuran file tidak boleh lebih dari :max kilobytes.',
            'exists' => ':attribute yang dipilih tidak valid.',
            'mimes' => 'File harus berformat: :values.',
        ];
    
        $attributes = [
            'beasiswa_id' => 'Beasiswa',
            'users_id' => 'Peserta',
            'hasil_ujian' => 'Hasil Ujian',
        ];
    
        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }


        try {
            $file = $request->file('hasil_ujian');
            $filename = Str::uuid() . '.' . $file->getClientOriginalExtension();
            $path = $file->storeAs('public/uploads', $filename);
            
            $pengajuan = Pengajuan::create([
                'beasiswa_id' => $request->beasiswa_id,
                'users_id' => $request->users_id,
                'hasil_ujian' => 'uploads/' . $filename,
            ]);
        }catch (QueryException $ex){
            return back()->with('error', $ex->getMessage())->withInput();
        }

        return redirect()->route('admin.pengajuan.index')->with('success', 'Berhasil membuat pengajuan');
    }

    public function edit($id){
        $beasiswa = Beasiswa::get();
        $users = User::where('role', 'peserta')->where('id', '!=', Session::get('user_id'))->get();
        $pengajuan = Pengajuan::where('id', $id)->first();
        return view('admin.pengajuan.edit', ['users' => $users, 'beasiswa' => $beasiswa, 'pengajuan' => $pengajuan]);
    }

    public function update(Request $request, $id){
        $rules = [
            'beasiswa_id' => 'required|exists:beasiswa,id',
            'users_id' => 'required|exists:users,id',
            'hasil_ujian' => 'nullable|file|max:2048|mimes:pdf,doc,docx',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'max' => 'Ukuran file tidak boleh lebih dari :max kilobytes.',
            'exists' => ':attribute yang dipilih tidak valid.',
            'mimes' => 'File harus berformat: :values.',
        ];
    
        $attributes = [
            'beasiswa_id' => 'Beasiswa',
            'users_id' => 'Peserta',
            'hasil_ujian' => 'Hasil Ujian',
        ];
    
        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $pengajuan = Pengajuan::where('id', $id)->first();
        try {
            $hasil_ujian = $pengajuan->hasil_ujian ?? '';
            if ($request->hasFile('hasil_ujian')) {
                $file = $request->file('hasil_ujian');
                $filename = Str::uuid() . '.' . $file->getClientOriginalExtension();
                $path = $file->storeAs('public/uploads', $filename);
                $hasil_ujian = 'uploads/' . $filename;
            }

            
            $pengajuan = Pengajuan::where('id', $id)->update([
                'beasiswa_id' => $request->beasiswa_id,
                'users_id' => $request->users_id,
                'hasil_ujian' => $hasil_ujian,
            ]);
        }catch (QueryException $ex){
            return back()->with('error', $ex->getMessage())->withInput();
        }

        return redirect()->route('admin.pengajuan.index')->with('success', 'Berhasil mengubah pengajuan');
    }

    public function delete($id){
        $pengajuan = Pengajuan::where('id', $id)->first();
        $pengajuan->delete();
        return redirect()->route('admin.pengajuan.index')->with('success', 'Berhasil menghapus pengajuan');
    }
}
