<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

class PetugasController extends Controller
{
    public function index(){
        $petugas = User::where('role', 'petugas')->get();
        return view('admin.petugas.index', ['petugas' => $petugas]);
    }

    public function create(){
        return view('admin.petugas.create');
    }

    public function store(Request $request){
        $rules = [
            'nama' => 'required|string|max:255',
            'nik' => 'required|integer|digits:16|unique:users,nik',
            'username' => 'required|string|max:255|unique:users,username',
            'alamat' => 'required|string|max:255',
            'no_hp' => 'required|string|max:16|unique:users,no_hp',
            'password' => 'min:8|required_with:confirm_password|same:confirm_password',
            'confirm_password' => 'min:8|required_with:password|same:password',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'integer' => ':attribute harus berupa angka.',
            'digits' => ':attribute harus terdiri dari :digits digit.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
            'min' => ':attribute tidak boleh kurang dari :min karakter.',
            'exists' => ':attribute yang dipilih tidak valid.',
            'unique' => ':attribute sudah terdaftar.',
            'required_with' => ':attribute harus di isi jika :values terisi',
            'same' => ':attribute tidak seusai dengan :other',
        ];
    
        $attributes = [
            'nama' => 'Nama',
            'nik' => 'NIK',
            'username' => 'Username',
            'alamat' => 'Alamat',
            'no_hp' => 'No HP',
            'password' => 'Password',
            'confirm_password' => 'Konfirmasi Password',
        ];

        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        DB::beginTransaction();
        try{
            User::create([
                'nama' => $request->nama ?? '',
                'nik' => $request->nik ?? '',
                'username' => $request->username ?? '',
                'alamat' => $request->alamat ?? '',
                'no_hp' => $request->no_hp ?? '',
                'status' => 1,
                'role' => 'petugas',
                'password' => Hash::make($request->password),
            ]);
            DB::commit();
        }catch(QueryException $ex){
            DB::rollback();
            return back()->with('error', $ex->getMessage())->withInput();
        }
        return redirect()->route('admin.petugas.index')->with('success', 'Berhasil menambahkan petugas');
    }

    public function edit($id){
        $petugas = User::where('id', $id)->where('role', 'petugas')->first();
        return view('admin.petugas.edit', ['petugas' => $petugas]);
    }

    public function update(Request $request, $id){
        $rules = [
            'nama' => 'required|string|max:255',
            'nik' => [
                'required',
                'digits:16',
                Rule::unique('users')->where(function ($query) use ($id, $request) {
                    return $query->where('nik', $request->nik)->where('id', '!=', $id);
                }),
            ],
            'username' => [
                'required',
                'string',
                'max:255',
                Rule::unique('users')->where(function ($query) use ($id, $request) {
                    return $query->where('username', $request->username)->where('id', '!=', $id);
                }),
            ],
            'alamat' => 'required|string|max:255',
            'no_hp' => [
                'required',
                'numeric',
                'digits_between:10,16',
                Rule::unique('users')->where(function ($query) use ($id, $request) {
                    return $query->where('no_hp', $request->no_hp)->where('id', '!=', $id);
                }),
            ],
            'password' => 'nullable|min:8|same:confirm_password',
            'confirm_password' => 'nullable|min:8|same:password',
        ];
    
        $messages = [
            'required' => ':attribute tidak boleh kosong.',
            'string' => ':attribute harus berupa teks.',
            'integer' => ':attribute harus berupa angka.',
            'digits' => ':attribute harus terdiri dari :digits digit.',
            'max' => ':attribute tidak boleh lebih dari :max karakter.',
            'min' => ':attribute tidak boleh kurang dari :min karakter.',
            'exists' => ':attribute yang dipilih tidak valid.',
            'unique' => ':attribute sudah terdaftar.',
            'required_with' => ':attribute harus di isi jika :values terisi',
            'same' => ':attribute tidak seusai dengan :other',
            'digits_between' => 'minimal 10 digit angka dan maksimal 16 digit angka',
        ];
    
        $attributes = [
            'nama' => 'Nama',
            'nik' => 'NIK',
            'username' => 'Username',
            'alamat' => 'Alamat',
            'no_hp' => 'No HP',
            'password' => 'Password',
            'confirm_password' => 'Konfirmasi Password',
        ];

        $validator = Validator::make($request->all(), $rules, $messages, $attributes);
    
        if ($validator->fails()) {
            return back()->withErrors($validator)->withInput();
        }

        $user = User::where('id', $id)->where('role', 'petugas')->first();

        DB::beginTransaction();
        try{
            $data = User::where('id', $id)->update([
                'nama' => $request->nama ?? $user->nama,
                'nik' => $request->nik ?? $user->nik,
                'username' => $request->username ?? $user->username,
                'alamat' => $request->alamat ?? $user->alamat,
                'no_hp' => $request->no_hp ?? $user->no_hp,
                'status' => 1,
                'role' => 'petugas',
            ]);
            if($request->password != ''){
                $user->update([
                    'password' => Hash::make($request->password),
                ]);
            }
            DB::commit();
        }catch(QueryException $ex){
            DB::rollback();
            return back()->with('error', $ex->getMessage())->withInput();
        }
        return redirect()->route('admin.petugas.index')->with('success', 'Berhasil mengupdate petugas');
    }

    public function delete($id){
        $ujian = User::where('id', $id)->first();
        $ujian->delete();
        return redirect()->route('admin.petugas.index')->with('success', 'Berhasil menghapus petugas');
    }
}
