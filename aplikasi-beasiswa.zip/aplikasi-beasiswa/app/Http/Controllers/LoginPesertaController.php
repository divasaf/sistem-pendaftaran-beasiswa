<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LoginPesertaController extends Controller
{
    //
}
