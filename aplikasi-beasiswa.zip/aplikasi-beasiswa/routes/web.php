<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FormController;
use App\Http\Controllers\UjianController;
use App\Http\Controllers\JurusanController;
use App\Http\Controllers\PesertaController;
use App\Http\Controllers\PetugasController;
use App\Http\Controllers\BeasiswaController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\PengajuanController;
use App\Http\Controllers\AuthPesertaController;
use App\Http\Controllers\AuthPetugasController;

Route::get('/', function () {
    return redirect('auth/login');
});

Route::get('users/create', [ FormController::class, 'create' ]);
Route::post('users/create', [ FormController::class, 'store' ])->name('users.store');

Route::group(['prefix' => 'admin', 'middleware' => 'isAuth', 'as' => 'admin.'], function () {
    Route::group(['prefix' => 'dashboard', 'as' => 'dashboard.'], function () {
        Route::get('/', [DashboardController::class, 'index'])->name('index');
    });

    Route::group(['prefix' => 'beasiswa', 'as' => 'beasiswa.'], function () {
        Route::get('/', [BeasiswaController::class, 'index'])->name('index');
        Route::get('/create', [BeasiswaController::class, 'create'])->name('create');
        Route::post('store', [ BeasiswaController::class, 'store' ])->name('store');
        Route::get('/edit/{id}', [BeasiswaController::class, 'edit'])->name('edit');
        Route::patch('/update/{id}', [BeasiswaController::class, 'update'])->name('update');
        Route::get('/delete/{id}', [BeasiswaController::class, 'delete'])->name('delete');
    });

    Route::group(['prefix' => 'jurusan', 'as' => 'jurusan.'], function () {
        Route::get('/', [JurusanController::class, 'index'])->name('index');
        Route::get('/create', [JurusanController::class, 'create'])->name('create');
        Route::post('store', [ JurusanController::class, 'store' ])->name('store');
        Route::get('/edit/{id}', [JurusanController::class, 'edit'])->name('edit');
        Route::patch('/update/{id}', [JurusanController::class, 'update'])->name('update');
        Route::get('/delete/{id}', [JurusanController::class, 'delete'])->name('delete');
    });

    Route::group(['prefix' => 'ujian', 'as' => 'ujian.'], function () {
        Route::get('/', [UjianController::class, 'index'])->name('index');
        Route::get('/create', [UjianController::class, 'create'])->name('create');
        Route::post('store', [ UjianController::class, 'store' ])->name('store');
        Route::get('/edit/{id}', [UjianController::class, 'edit'])->name('edit');
        Route::patch('/update/{id}', [UjianController::class, 'update'])->name('update');
        Route::get('/delete/{id}', [UjianController::class, 'delete'])->name('delete');
    });

    Route::group(['prefix' => 'pengajuan', 'as' => 'pengajuan.'], function () {
        Route::get('/', [PengajuanController::class, 'index'])->name('index');
        Route::get('/create', [PengajuanController::class, 'create'])->name('create');
        Route::post('store', [ PengajuanController::class, 'store' ])->name('store');
        Route::get('/edit/{id}', [PengajuanController::class, 'edit'])->name('edit');
        Route::patch('/update/{id}', [PengajuanController::class, 'update'])->name('update');
        Route::get('/delete/{id}', [PengajuanController::class, 'delete'])->name('delete');
    });

    Route::group(['prefix' => 'peserta', 'as' => 'peserta.'], function () {
        Route::get('/', [PesertaController::class, 'index'])->name('index');
        Route::get('/create', [PesertaController::class, 'create'])->name('create');
        Route::post('store', [ PesertaController::class, 'store' ])->name('store');
        Route::get('/edit/{id}', [PesertaController::class, 'edit'])->name('edit');
        Route::patch('/update/{id}', [PesertaController::class, 'update'])->name('update');
        Route::get('/delete/{id}', [PesertaController::class, 'delete'])->name('delete');
    });

    Route::group(['prefix' => 'petugas', 'as' => 'petugas.'], function () {
        Route::get('/', [PetugasController::class, 'index'])->name('index');
        Route::get('/create', [PetugasController::class, 'create'])->name('create');
        Route::post('store', [ PetugasController::class, 'store' ])->name('store');
        Route::get('/edit/{id}', [PetugasController::class, 'edit'])->name('edit');
        Route::patch('/update/{id}', [PetugasController::class, 'update'])->name('update');
        Route::get('/delete/{id}', [PetugasController::class, 'delete'])->name('delete');
    });
});

Route::group(['prefix' => 'auth', 'as' => 'auth.'], function () {
    Route::get('login', [AuthPesertaController::class, 'login'])->name('login');
    Route::post('login', [AuthPesertaController::class, 'loginPost'])->name('login.post');
    Route::get('register', [AuthPesertaController::class, 'register'])->name('register');
    Route::post('register', [AuthPesertaController::class, 'registerPost'])->name('register.post');
    Route::get('logout', [AuthPesertaController::class, 'logout'])->name('logout');

    Route::group(['prefix' => 'petugas', 'as' => 'petugas.'], function () {
        Route::get('login', [AuthPetugasController::class, 'login'])->name('login');
        Route::post('login', [AuthPetugasController::class, 'loginPost'])->name('login.post');
        Route::get('register', [AuthPetugasController::class, 'register'])->name('register');
        Route::post('register', [AuthPetugasController::class, 'registerPost'])->name('register.post');
    });
});
