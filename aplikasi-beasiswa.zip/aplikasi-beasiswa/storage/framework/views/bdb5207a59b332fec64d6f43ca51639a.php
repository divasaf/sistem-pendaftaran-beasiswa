<?php $__env->startSection('title'); ?>
    Admin | Peserta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="conttainer-md">

    <h3>Peserta</h3>

    <a href="<?php echo e(route('admin.peserta.create')); ?>" type="button" class="btn btn-success"> + Tambah Peserta</a>

    <br />
    <br />
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Alamat</th>
                <th>No Hp</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($peserta) > 0): ?>
                <?php $__currentLoopData = $peserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?= $loop->index + 1 ?></td>
                    <td><?php echo e($p->nama); ?></td>
                    <td><?php echo e($p->nik); ?></td>
                    <td><?php echo e($p->alamat); ?></td>
                    <td><?php echo e($p->no_hp); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.peserta.edit', $p->id)); ?>" type="button" class="btn btn-success">Edit</a>
                        |
                        <a href="<?php echo e(route('admin.peserta.delete', $p->id)); ?>" type="button" onclick="return confirm('Yakin ingin menghapus data？')" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
                <tr>
                    <td colspan="6" class="text-center"><h3>Tidak Ada Data</h3></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/aplikasi-beasiswa/resources/views/admin/peserta/index.blade.php ENDPATH**/ ?>