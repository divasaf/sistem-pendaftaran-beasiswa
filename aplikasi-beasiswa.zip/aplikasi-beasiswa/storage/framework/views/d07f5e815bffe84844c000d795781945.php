<?php $__env->startSection('title'); ?>
    Admin | Pengajuan | Edit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h3>Form Edit Pengajuan</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="<?php echo e(route('admin.pengajuan.update', $pengajuan->id)); ?>" method="POST" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label for="beasiswa_id">Beasiswa</label>
                        <select name="beasiswa_id" id="beasiswa_id" class="form-control">
                            <option value="">Pilih Beasiswa</option>
                            <?php $__currentLoopData = $beasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($b->id ?? ''); ?>" <?php echo e(old('beasiswa_id') == $b->id ? 'selected' : ''); ?> <?php echo e($pengajuan->beasiswa_id == $b->id ? 'selected' : ''); ?>><?php echo e($b->nama ?? ''); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('beasiswa_id')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('beasiswa_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="users_id">Peserta</label>
                        <select name="users_id" id="users_id" class="form-control">
                            <option value="">Pilih Peserta</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($u->id ?? ''); ?>" <?php echo e(old('users_id') == $u->id ? 'selected' : ''); ?> <?php echo e($pengajuan->users_id == $b->id ? 'selected' : ''); ?>><?php echo e($u->nama . ' - ' . $u->nik ?? ''); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php if($errors->has('users_id')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('users_id')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="hasil_ujian">Hasil Ujian</label>
                        <input type="file" name="hasil_ujian" id="hasil_ujian" class="form-control" value="<?php echo e(old('hasil_ujian' ?? '')); ?>">
                        <?php if($errors->has('hasil_ujian')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('hasil_ujian')); ?></span>
                        <?php endif; ?>
                    </div>
                    <a href="<?php echo e(Storage::url($pengajuan->hasil_ujian)); ?>" target="_blank">File sebelumnya</a>
                    <br>
                    <button type="submit" class="btn btn-success mt-4">Simpan</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/aplikasi-beasiswa/resources/views/admin/pengajuan/edit.blade.php ENDPATH**/ ?>