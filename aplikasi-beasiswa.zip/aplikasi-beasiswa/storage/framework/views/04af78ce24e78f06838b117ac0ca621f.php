<?php $__env->startSection('title'); ?>
    Admin | Beasiswa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="conttainer-md">

    <h3>Beasiswa</h3>

    <a href="<?php echo e(route('admin.beasiswa.create')); ?>" type="button" class="btn btn-success"> + Tambah Beasiswa</a>

    <br />
    <br />
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Nama Beasiswa</th>
                <th>Sponsor</th>
                <th>Jurusan</th>
                <th>Ujian</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($beasiswa) > 0): ?>
                <?php $__currentLoopData = $beasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?= $loop->index + 1 ?></td>
                    <td><?php echo e($b->nama); ?></td>
                    <td><?php echo e($b->sponsor); ?></td>
                    <td><?php echo e($b->jurusan->nama ?? ''); ?></td>
                    <td><?php echo e($b->ujian->nama ?? ''); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.beasiswa.edit', $b->id)); ?>" type="button" class="btn btn-success">Edit</a>
                        |
                        <a href="<?php echo e(route('admin.beasiswa.delete', $b->id)); ?>" type="button" onclick="return confirm('Yakin ingin menghapus data？')" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
                <tr>
                    <td colspan="6" class="text-center"><h3>Tidak Ada Data</h3></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/aplikasi-beasiswa/resources/views/admin/beasiswa/index.blade.php ENDPATH**/ ?>