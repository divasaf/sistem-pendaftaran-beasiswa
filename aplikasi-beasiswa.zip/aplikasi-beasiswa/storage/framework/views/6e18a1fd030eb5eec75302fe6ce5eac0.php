<?php $__env->startSection('content'); ?>


<h1>SELAMAT DATANG DI DASHBOARD ADMIN!</h1>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/aplikasi-beasiswa/resources/views/dashboard.blade.php ENDPATH**/ ?>