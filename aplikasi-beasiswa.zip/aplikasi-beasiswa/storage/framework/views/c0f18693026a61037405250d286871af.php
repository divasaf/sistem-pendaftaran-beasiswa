<?php $__env->startSection('title'); ?>
    Admin | Petugas
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="conttainer-md">

    <h3>Petugas</h3>

    <a href="<?php echo e(route('admin.petugas.create')); ?>" type="button" class="btn btn-success"> + Tambah Petugas</a>

    <br />
    <br />
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Nama</th>
                <th>NIK</th>
                <th>Alamat</th>
                <th>No Hp</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($petugas) > 0): ?>
                <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?= $loop->index + 1 ?></td>
                    <td><?php echo e($p->nama); ?></td>
                    <td><?php echo e($p->nik); ?></td>
                    <td><?php echo e($p->alamat); ?></td>
                    <td><?php echo e($p->no_hp); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.petugas.edit', $p->id)); ?>" type="button" class="btn btn-success">Edit</a>
                        |
                        <a href="<?php echo e(route('admin.petugas.delete', $p->id)); ?>" type="button" onclick="return confirm('Yakin ingin menghapus data？')" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
                <tr>
                    <td colspan="6" class="text-center"><h3>Tidak Ada Data</h3></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aplikasi-beasiswa\resources\views/admin/petugas/index.blade.php ENDPATH**/ ?>