<?php $__env->startSection('title'); ?>
    Admin | Petugas | Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h3>Form Create Petugas</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="<?php echo e(route('admin.petugas.update', $petugas->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="text" name="nik" id="nik" class="form-control" value="<?php echo e(old('nik', $petugas->nik ?? '')); ?>">
                        <?php if($errors->has('nik')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('nik')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e(old('nama', $petugas->nama ?? '')); ?>">
                        <?php if($errors->has('nama')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('nama')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" class="form-control" value="<?php echo e(old('username', $petugas->username ?? '')); ?>">
                        <?php if($errors->has('username')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('username')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control" value="<?php echo e(old('alamat', $petugas->alamat ?? '')); ?>">
                        <?php if($errors->has('alamat')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('alamat')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="no_hp">No Handphone</label>
                        <input type="text" name="no_hp" id="no_hp" class="form-control" value="<?php echo e(old('no_hp', $petugas->no_hp ?? '')); ?>">
                        <?php if($errors->has('no_hp')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('no_hp')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control" value="<?php echo e(old('password' ?? '')); ?>">
                        <?php if($errors->has('password')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Password Confirmation</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" value="<?php echo e(old('confirm_password' ?? '')); ?>">
                        <?php if($errors->has('confirm_password')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('confirm_password')); ?></span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/aplikasi-beasiswa/resources/views/admin/petugas/edit.blade.php ENDPATH**/ ?>