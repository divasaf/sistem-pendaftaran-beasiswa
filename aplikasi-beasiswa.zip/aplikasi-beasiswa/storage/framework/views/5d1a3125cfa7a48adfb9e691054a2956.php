<?php $__env->startSection('title'); ?>
    Admin | Ujian
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<div class="conttainer-md">

    <h3>Ujian</h3>

    <a href="<?php echo e(route('admin.ujian.create')); ?>" type="button" class="btn btn-success"> + Tambah Ujian</a>

    <br />
    <br />
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>No</th>
                <th>Nama Ujian</th>
                <th>Link</th>
                <th>Opsi</th>
            </tr>
        </thead>
        <tbody>
            <?php if(count($ujian) > 0): ?>
                <?php $__currentLoopData = $ujian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td scope="row"><?= $loop->index + 1 ?></td>
                    <td><?php echo e($u->nama); ?></td>
                    <td><?php echo e($u->link); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.ujian.edit', $u->id)); ?>" type="button" class="btn btn-success">Edit</a>
                        |
                        <a href="<?php echo e(route('admin.ujian.delete', $u->id)); ?>" type="button" onclick="return confirm('Yakin ingin menghapus data？')" class="btn btn-danger">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?> 
                <tr>
                    <td colspan="6" class="text-center"><h3>Tidak Ada Data</h3></td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/aplikasi-beasiswa/resources/views/admin/ujian/index.blade.php ENDPATH**/ ?>