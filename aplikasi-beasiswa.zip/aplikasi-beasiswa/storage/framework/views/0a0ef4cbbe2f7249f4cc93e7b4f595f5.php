<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Bootstrap CSS -->
    <link href="<?php echo e(asset('assets_wb/vendor/fontawesome-free/css/all.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets_wb/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">

    <!-- Custom styles for this template-->
    <!-- my css -->
    <link rel="stylesheet" href="<?php echo e(asset('assets_wb/css/style.css')); ?>">
    <style>
        html, body {
            height: 100%;
        }
        .card-container {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100%;
        }
    </style>
</head>
<body>
    <div class="container card-container">
        <div class="card shadow-sm" style="width: 100%; max-width: 600px;">
            <div class="card-body">
                <h3 class="card-title text-center mb-4">Register Peserta</h3>
                <form action="<?php echo e(route('auth.register.post')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="text" name="nik" id="nik" class="form-control" value="<?php echo e(old('nik', rand(1111111111111111, 9999999999999999))); ?>">
                        <?php if($errors->has('nik')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('nik')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="nama">Nama</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e(old('nama' ?? '')); ?>">
                        <?php if($errors->has('nama')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('nama')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="username">Username</label>
                        <input type="text" name="username" id="username" class="form-control" value="<?php echo e(old('username' ?? '')); ?>">
                        <?php if($errors->has('username')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('username')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="alamat">Alamat</label>
                        <input type="text" name="alamat" id="alamat" class="form-control" value="<?php echo e(old('alamat' ?? '')); ?>">
                        <?php if($errors->has('alamat')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('alamat')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="no_hp">No Handphone</label>
                        <input type="text" name="no_hp" id="no_hp" class="form-control" value="<?php echo e(old('no_hp' ?? '')); ?>">
                        <?php if($errors->has('no_hp')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('no_hp')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="password">Password</label>
                        <input type="password" name="password" id="password" class="form-control" value="<?php echo e(old('password' ?? '')); ?>">
                        <?php if($errors->has('password')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('password')); ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="confirm_password">Password Confirmation</label>
                        <input type="password" name="confirm_password" id="confirm_password" class="form-control" value="<?php echo e(old('confirm_password' ?? '')); ?>">
                        <?php if($errors->has('confirm_password')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('confirm_password')); ?></span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-primary w-100">Register</button>
                </form>
                <br>
                <div class="row">
                    <div class="col-md-6">
                        <a href="<?php echo e(route('auth.login')); ?>" style="">Login?</a>
                    </div>
                    <div class="col-md-6 text-right">
                        <a href="<?php echo e(route('auth.petugas.login')); ?>" style="">Login Sebagai Petugas?</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\aplikasi-beasiswa\resources\views/auth/peserta/register.blade.php ENDPATH**/ ?>