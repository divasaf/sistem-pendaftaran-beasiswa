<?php $__env->startSection('title'); ?>
    Admin | Jurusan | Create
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <h3>Form Create Jurusan</h3>
        <div class="row mt-4">

            <div class="col-md-6">
                <form action="<?php echo e(route('admin.jurusan.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="nama">Nama Jurusan</label>
                        <input type="text" name="nama" id="nama" class="form-control" value="<?php echo e(old('nama' ?? '')); ?>">
                        <?php if($errors->has('nama')): ?>
                            <span style="font-size: 13px; color: rgb(192, 40, 40);"><?php echo e($errors->first('nama')); ?></span>
                        <?php endif; ?>
                    </div>
                    <button type="submit" class="btn btn-success">Simpan</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.template-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/html/aplikasi-beasiswa/resources/views/admin/jurusan/create.blade.php ENDPATH**/ ?>